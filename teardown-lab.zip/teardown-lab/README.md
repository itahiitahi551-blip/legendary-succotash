# Teardown Lab — Interactive Product Teardown & Analysis Hub

A static, dependency-free prototype of an engineering-style product teardown dashboard.

## Included
- Interactive exploded product view rendered with Canvas.
- Explode-depth slider from assembled to maximum teardown.
- Mouse drag rotation of the analysis viewport.
- Clickable component inspection cards with supplier, estimated cost, material, function, score and engineering note.
- Product health / BOM / repairability dashboard.
- Workload slider with dynamic thermal envelope, peak temperature and headroom.
- Responsive dark-futuristic UI for desktop and mobile.

## Run locally
Open `index.html` in a browser. No build step or package installation is required.

## GitHub Pages
This project is ready to host as a static site. Upload the files to the repository root and enable GitHub Pages from the repository settings using the `main` branch and `/ (root)` folder.
