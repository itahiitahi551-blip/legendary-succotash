const canvas = document.getElementById('teardownCanvas');
const ctx = canvas.getContext('2d');
const wrap = document.getElementById('canvasWrap');

const components = [
  {id:'C-01',name:'Rear Shell',short:'R',type:'Structural enclosure',supplier:'Nova Materials Co.',cost:18.4,material:'Aero-glass / aluminum',score:8.7,perf:'Impact protection',note:'Dual-material shell with localized reinforcement around camera and mid-frame mounts.'},
  {id:'C-02',name:'Display Stack',short:'D',type:'LTPO OLED assembly',supplier:'VisionTek Display',cost:61.2,material:'Flexible OLED / ceramic',score:9.4,perf:'Visual fidelity',note:'Low-power LTPO panel with rigid ceramic top layer and laminated touch stack.'},
  {id:'C-03',name:'Battery Pack',short:'B',type:'5,100 mAh cell',supplier:'Hikari Energy',cost:24.8,material:'Silicon-carbon composite',score:8.5,perf:'Energy density',note:'Large-format pouch cell mounted on a graphite spreader with pull-tab service access.'},
  {id:'C-04',name:'Logic Board',short:'L',type:'Main compute PCB',supplier:'Atlas Semiconductor',cost:73.5,material:'FR-4 / copper / silicon',score:9.1,perf:'Compute platform',note:'High-density mainboard with stacked memory package, RF shields, and dedicated PMIC zones.'},
  {id:'C-05',name:'Camera Module',short:'C',type:'Triple sensor cluster',supplier:'Optix Imaging',cost:32.7,material:'Glass / silicon / steel',score:8.9,perf:'Imaging system',note:'Three stabilized modules with short flex routing and a direct frame mount to reduce camera wobble.'},
  {id:'C-06',name:'Thermal Stack',short:'T',type:'Vapor chamber + graphite',supplier:'ThermoCore',cost:12.9,material:'Copper / graphite',score:9.3,perf:'Heat dissipation',note:'Oversized vapor chamber spreads hotspot energy toward the mid-frame before surface transfer.'}
];
let selected = 3; let explode = 68; let load = 42; let compact = false; let angle = 0; let drag = false; let lastX = 0;

function resize(){ const dpr=window.devicePixelRatio||1; const r=wrap.getBoundingClientRect(); canvas.width=r.width*dpr; canvas.height=r.height*dpr; canvas.style.width=r.width+'px'; canvas.style.height=r.height+'px'; ctx.setTransform(dpr,0,0,dpr,0,0); draw(); }
window.addEventListener('resize',resize);

function projectPoint(x,y,z){ const r=wrap.getBoundingClientRect(); const cx=r.width/2, cy=r.height*.49; const cos=Math.cos(angle), sin=Math.sin(angle); const xr=x*cos-z*sin; const zr=x*sin+z*cos; return {x:cx+xr, y:cy+y-zr*.28}; }
function roundRectPath(c,x,y,w,h,r){ c.beginPath(); c.roundRect(x,y,w,h,r); }
function drawPhoneLayer(layer, gap, idx, scale){
  const w=112*scale, h=212*scale; const z=(idx-2.5)*gap; const p=projectPoint(z, idx*7-18, z*.3); const rot=angle*.15 + (idx-2)*0.01;
  ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(rot);
  ctx.shadowBlur=layer.shadow?28:12; ctx.shadowColor=layer.glow;
  roundRectPath(ctx,-w/2,-h/2,w,h,16*scale); ctx.fillStyle=layer.fill; ctx.fill(); ctx.lineWidth=1.15; ctx.strokeStyle=layer.stroke; ctx.stroke(); ctx.shadowBlur=0;
  if(layer.detail){ctx.fillStyle=layer.detail; layer.detail({c:ctx,w,h,scale});}
  ctx.restore();
}
function boardDetails({c,w,h,scale}){c.globalAlpha=.95;c.fillStyle='#14343d';c.fillRect(-w*.31,-h*.29,w*.22,h*.46);c.fillRect(w*.08,-h*.28,w*.25,h*.12);c.fillRect(w*.12,-h*.06,w*.2,h*.2);c.fillStyle='#45e7ff';c.fillRect(-w*.02,-h*.25,w*.08,h*.09);c.fillRect(-w*.22,h*.13,w*.12,h*.04);c.globalAlpha=1;}
function batteryDetails({c,w,h,scale}){c.strokeStyle='#355765';c.lineWidth=1;c.strokeRect(-w*.32,-h*.28,w*.64,h*.56);c.fillStyle='rgba(83,239,173,.16)';c.fillRect(-w*.22,-h*.18,w*.44,h*.36);c.fillStyle='#87a7b1';c.font=`${8*scale}px Inter`;c.fillText('NX 5100',-w*.17,2);}
function cameraDetails({c,w,h,scale}){for(let i=0;i<3;i++){c.beginPath();c.arc(-w*.22+i*w*.22,-h*.22,11*scale,0,Math.PI*2);c.fillStyle='#07131a';c.fill();c.strokeStyle='#4a6d78';c.stroke();c.beginPath();c.arc(-w*.22+i*w*.22,-h*.22,5*scale,0,Math.PI*2);c.fillStyle='#2d5562';c.fill();}}
function thermalDetails({c,w,h,scale}){c.fillStyle='rgba(255,141,71,.24)';c.fillRect(-w*.31,-h*.18,w*.62,h*.36);c.strokeStyle='#bc6641';c.strokeRect(-w*.31,-h*.18,w*.62,h*.36);for(let y=-h*.09;y<h*.1;y+=h*.06){c.strokeStyle='rgba(255,185,120,.5)';c.beginPath();c.moveTo(-w*.25,y);c.lineTo(w*.25,y);c.stroke();}}
const layers=[
 {name:'Rear Shell',fill:'#0b171d',stroke:'#36515c',glow:'rgba(69,231,255,.08)',shadow:false},
 {name:'Display',fill:'#102e36',stroke:'#3d8b9b',glow:'rgba(69,231,255,.22)',shadow:true},
 {name:'Battery',fill:'#13272d',stroke:'#53efad',glow:'rgba(83,239,173,.13)',detail:batteryDetails,shadow:false},
 {name:'Logic Board',fill:'#0d252d',stroke:'#45e7ff',glow:'rgba(69,231,255,.23)',detail:boardDetails,shadow:true},
 {name:'Camera',fill:'#172830',stroke:'#89b8c3',glow:'rgba(137,184,195,.15)',detail:cameraDetails,shadow:false},
 {name:'Thermal Stack',fill:'#30241d',stroke:'#ff8d47',glow:'rgba(255,141,71,.2)',detail:thermalDetails,shadow:false}
];
function draw(){
  const r=wrap.getBoundingClientRect(); ctx.clearRect(0,0,r.width,r.height);
  const scale=Math.min(r.width/720, r.height/560); const gap=compact?7:(5+explode*.3);
  // shadow platform
  const s=projectPoint(0,102,0); ctx.beginPath();ctx.ellipse(s.x,s.y,125*scale,28*scale,0,0,Math.PI*2);ctx.fillStyle='rgba(0,0,0,.5)';ctx.filter='blur(8px)';ctx.fill();ctx.filter='none';
  layers.forEach((layer,i)=>drawPhoneLayer(layer,gap,i,scale));
  // connector traces
  ctx.save();ctx.strokeStyle='rgba(69,231,255,.25)';ctx.setLineDash([3,6]);ctx.lineWidth=1;
  for(let i=0;i<5;i++){const a=projectPoint((i-2)*gap,-72,0);const b=projectPoint((i-2)*gap,79,0);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}ctx.restore();
  // hotspots / selection
  const hot=projectPoint(0,0,(selected-2.5)*gap); ctx.beginPath();ctx.arc(hot.x,hot.y,7+Math.sin(Date.now()/260)*2,0,Math.PI*2);ctx.fillStyle='rgba(69,231,255,.15)';ctx.fill();ctx.beginPath();ctx.arc(hot.x,hot.y,2.5,0,Math.PI*2);ctx.fillStyle='#45e7ff';ctx.fill();
  requestAnimationFrame(()=>{});
}
function setSelected(i){ selected=i; renderInspector(); renderIndex(); draw(); document.getElementById('hoverInfo').textContent=`${components[i].id} // ${components[i].name.toUpperCase()}`; }
function renderInspector(){const c=components[selected]; document.getElementById('componentTitle').textContent=c.name;document.getElementById('componentId').textContent=c.id;document.getElementById('scoreValue').textContent=c.score.toFixed(1);document.getElementById('scoreStars').textContent='★★★★★'.slice(0,Math.round(c.score/2))+'☆☆☆☆☆'.slice(0,5-Math.round(c.score/2));document.getElementById('specList').innerHTML=`<div class="spec"><label>SUPPLIER</label><strong>${c.supplier}</strong></div><div class="spec"><label>EST. COST</label><strong>$${c.cost.toFixed(2)}</strong></div><div class="spec"><label>MATERIAL</label><strong>${c.material}</strong></div><div class="spec"><label>FUNCTION</label><strong>${c.perf}</strong></div>`;document.getElementById('componentNote').textContent=c.note;}
function renderIndex(){document.getElementById('componentIndex').innerHTML=components.map((c,i)=>`<div class="index-item ${i===selected?'active':''}" data-i="${i}"><div class="index-icon">${c.short}</div><div><div class="index-name">${c.name}</div><div class="index-detail">${c.type}</div></div><div class="index-cost">$${c.cost.toFixed(1)}</div></div>`).join('');document.querySelectorAll('.index-item').forEach(el=>el.addEventListener('click',()=>setSelected(Number(el.dataset.i))));}
function updateThermal(){ const temp=30.1+(load*0.205); const head=Math.max(0,100-load*0.72); document.getElementById('loadValue').textContent=load+'%'; document.getElementById('peakTemp').textContent=temp.toFixed(1)+'°C'; document.getElementById('thermalHeadroom').textContent=Math.round(head)+'%'; document.getElementById('headroomBar').style.width=head+'%'; const state=load<65?'STABLE THERMAL STATE':load<86?'HIGH THERMAL LOAD':'THERMAL THROTTLE RISK'; document.getElementById('thermalState').textContent=state; document.getElementById('thermalState').style.color=load<65?'#53efad':load<86?'#ffbd68':'#ff626b'; document.querySelectorAll('.thermal-hotspot').forEach(function(el,i){el.style.transform='scale('+(0.75+load/155+i*0.05)+')';}); document.querySelector('.thermal-core').style.opacity=(0.35+load/110).toFixed(2); document.getElementById('bomCost').textContent='$'+(238.4+Math.max(0,load-65)*0.1).toFixed(2); }

document.getElementById('explodeSlider').addEventListener('input',e=>{explode=Number(e.target.value);document.getElementById('explodeValue').textContent=`${explode}%`;draw();});
document.getElementById('loadSlider').addEventListener('input',e=>{load=Number(e.target.value);updateThermal();});
document.querySelectorAll('.chip').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');compact=b.dataset.mode==='compact';draw();}));
document.getElementById('resetView').addEventListener('click',()=>{explode=68;load=42;angle=0;compact=false;document.getElementById('explodeSlider').value=68;document.getElementById('loadSlider').value=42;document.getElementById('explodeValue').textContent='68%';document.querySelectorAll('.chip').forEach(x=>x.classList.toggle('active',x.dataset.mode==='exploded'));setSelected(3);updateThermal();});
canvas.addEventListener('pointerdown',e=>{drag=true;lastX=e.clientX;canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!drag)return;angle+=(e.clientX-lastX)*.009;lastX=e.clientX;draw()});canvas.addEventListener('pointerup',()=>drag=false);canvas.addEventListener('pointercancel',()=>drag=false);
canvas.addEventListener('click',e=>{if(drag)return;const r=wrap.getBoundingClientRect();const scale=Math.min(r.width/720,r.height/560);const gap=compact?7:(5+explode*.3);let closest=0,dist=Infinity;layers.forEach((_,i)=>{const p=projectPoint((i-2.5)*gap,i*7-18,(i-2.5)*gap*.3);const d=Math.hypot(e.clientX-r.left-p.x,e.clientY-r.top-p.y);if(d<dist){dist=d;closest=i}});setSelected(closest)});
renderInspector();renderIndex();updateThermal();resize();
